﻿namespace AssignmentBAL
{
    public class Class1
    {

    }
}
//Scaffold - DbContext "Host=localhost; Database=Hospital; Username=postgres; Password=2002; Integrated Security=true; Pooling=true;" Npgsql.EntityFrameworkCore.PostgreSQL - OutputDir "Models" - context "ApplicationDbContext" - contextDir "Data" - f;