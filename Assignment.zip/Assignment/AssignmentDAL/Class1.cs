﻿namespace AssignmentDAL
{
    public class Class1
    {

    }
}